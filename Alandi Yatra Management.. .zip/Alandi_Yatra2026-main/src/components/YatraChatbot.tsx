import React, { useState } from 'react';
import { Bot, X, Send, MessageCircle, User } from 'lucide-react';

type ChatMessage = { role: 'bot' | 'user'; text: string };
const faq: Array<{ keywords: string[]; answer: string }> = [
  { keywords: ['register', 'registration', 'pass', 'नोंदणी'], answer: 'To register, use “Register as Pilgrim” on the home page and complete the form. Keep your mobile number and emergency contact details ready.' },
  { keywords: ['stay', 'room', 'bed', 'dharamshala', 'accommodation', 'shelter'], answer: 'Open “Book Dharamshala” or the Accommodation section to view shelters and submit a bed request. Availability may change, so wait for confirmation.' },
  { keywords: ['map', 'location', 'water', 'medical', 'food', 'toilet'], answer: 'Open the Interactive Map to locate listed facilities such as food centres, water points, medical centres and accommodation.' },
  { keywords: ['emergency', 'ambulance', 'help', 'sos'], answer: 'For an urgent situation, use the red “Emergency SOS” button in the app. For immediate danger, contact local emergency services directly.' },
  { keywords: ['date', 'when', 'schedule', 'event', 'yatra'], answer: 'Check the Main Yatra Event card and Live Announcements on the home page for the event schedule and updates.' },
  { keywords: ['hello', 'hi', 'namaskar', 'नमस्कार'], answer: 'Namaskar! 🙏 I can help with pilgrim registration, passes, accommodation, facilities and yatra announcements. What would you like to know?' },
];
function getAnswer(question: string) {
  const q = question.toLowerCase();
  return faq.find(item => item.keywords.some(word => q.includes(word)))?.answer
    ?? 'I can help with registration, pilgrim passes, accommodation, the facilities map, emergency SOS and announcements. Try asking about one of these topics. For official confirmation, please check the latest announcement or contact the Yatra help desk.';
}

export const YatraChatbot: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'bot', text: 'Namaskar! 🙏 Welcome to Alandi Yatra help. How can I assist you today?' }]);
  const send = (text = input) => {
    const question = text.trim();
    if (!question) return;
    setMessages(old => [...old, { role: 'user', text: question }, { role: 'bot', text: getAnswer(question) }]);
    setInput('');
  };
  return <div className="fixed bottom-5 right-5 z-[100]">
    {open && <section className="mb-3 flex h-[min(500px,70vh)] w-[min(360px,calc(100vw-2rem))] flex-col overflow-hidden rounded-2xl border border-orange-200 bg-white shadow-2xl" aria-label="Alandi Yatra chatbot">
      <header className="flex items-center justify-between bg-orange-700 px-4 py-3 text-white"><div className="flex items-center gap-2"><span className="rounded-full bg-white/20 p-2"><Bot className="h-5 w-5" /></span><div><p className="font-bold">Mauli Help Assistant</p><p className="text-xs text-orange-100">Alandi Yatra · FAQ support</p></div></div><button onClick={() => setOpen(false)} aria-label="Close chat" className="rounded-lg p-1 hover:bg-white/20"><X className="h-5 w-5" /></button></header>
      <div className="flex-1 space-y-3 overflow-y-auto bg-orange-50/50 p-3">{messages.map((m, i) => <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>{m.role === 'bot' && <Bot className="mt-1 h-5 w-5 shrink-0 text-orange-700" />}<p className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm leading-relaxed ${m.role === 'user' ? 'bg-orange-700 text-white' : 'border border-orange-100 bg-white text-stone-800'}`}>{m.text}</p>{m.role === 'user' && <User className="mt-1 h-5 w-5 shrink-0 text-stone-500" />}</div>)}</div>
      <div className="border-t border-stone-100 bg-white p-3"><div className="mb-2 flex flex-wrap gap-1.5">{['Register / pass', 'Accommodation', 'Facilities map'].map(s => <button key={s} onClick={() => send(s)} className="rounded-full border border-orange-200 px-2.5 py-1 text-[11px] font-semibold text-orange-800 hover:bg-orange-50">{s}</button>)}</div><form onSubmit={e => { e.preventDefault(); send(); }} className="flex gap-2"><input value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about the yatra…" className="min-w-0 flex-1 rounded-xl border border-stone-200 px-3 py-2 text-sm outline-none focus:border-orange-500" aria-label="Message"/><button type="submit" aria-label="Send message" className="rounded-xl bg-orange-700 px-3 text-white hover:bg-orange-800"><Send className="h-4 w-4" /></button></form><p className="mt-2 text-[10px] text-stone-400">Automated FAQ assistant · verify urgent or official details with organisers.</p></div>
    </section>}
    <button onClick={() => setOpen(v => !v)} aria-label={open ? 'Close help chat' : 'Open help chat'} className="ml-auto flex items-center gap-2 rounded-full bg-orange-700 px-4 py-3 font-bold text-white shadow-xl transition hover:-translate-y-0.5 hover:bg-orange-800"><MessageCircle className="h-5 w-5"/><span>{open ? 'Close help' : 'Ask Mauli'}</span></button>
  </div>;
};
